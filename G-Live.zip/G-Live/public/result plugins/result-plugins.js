﻿PLUGINSRES=[
 {
	"name":'Photo to buy',
	"condition":'%b%>50',
	"content":'<a href="https://my-photo-partner.com/races/my-race/find?bib=%b%" style="margin:20px 0;padding:10px">Buy your photo souvenir of the race here!</a>'
 }
]